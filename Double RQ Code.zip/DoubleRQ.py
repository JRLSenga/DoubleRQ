
import numpy as np
from ModifiedFedergruenandZheng2 import ModifiedFedergruenAndZheng

class Simulation:
    def __init__(self, r_p, Q_p, r_r, Q_r, K_p, K_r, c_p, c_r, h_p, h_r, b, demand_rate, return_rate, L_p, L_r, TimeToSteadyState): #initializer
        self.serviceable_inventory = r_p + Q_p
        self.inventory_position = r_p + Q_p
        self.returns_inventory = 0.0

        #initialization of clock, and interarrival times
        self.clock = 0.0
        self.demand_rate = demand_rate
        self.return_rate = return_rate
        self.t_demand = self.generate_interarrival_demand()
        self.t_returns = self.generate_interarrival_returns()
        self.t_mfgLeadTime = [float("inf")]
        self.t_remfgLeadTime = [float("inf")]

        #cost initialization
        self.cost_total = 0.0
        self.cost_orders_mfg = 0.0
        self.cost_orders_remfg = 0.0
        self.cost_holding_serviceable = 0.0
        self.cost_holding_returns = 0.0
        self.cost_backorder = 0.0

        #parameter setups - taken from the inputs of the simulation
        self.r_p = r_p
        self.Q_p = Q_p
        self.r_r = r_r
        self.Q_r = Q_r
        self.c_p = c_p
        self.c_r = c_r
        self.K_p = K_p
        self.K_r = K_r
        self.h_p = h_p
        self.h_r = h_r
        self.b = b

        self.L_p = L_p
        self.L_r = L_r

        self.TimeToSteadyState = TimeToSteadyState

        # print self.cost_total
    #advances time in the simulation
    def advance_time(self):
        # print "t_event: ", self.t_demand, self.t_returns, self.t_mfgLeadTime[0], self.t_remfgLeadTime[0]
        t_event = min(self.t_demand, self.t_returns, self.t_remfgLeadTime[0], self.t_mfgLeadTime[0])


        if self.clock >= self.TimeToSteadyState:
            self.cost_holding_serviceable += (self.h_p * max(self.serviceable_inventory,0))*(t_event - self.clock)
            self.cost_holding_returns += (self.h_r * self.returns_inventory)*(t_event - self.clock)
            self.cost_backorder -= (self.b * min(self.serviceable_inventory, 0))*(t_event - self.clock)


            self.cost_total += ((self.h_p * max(self.serviceable_inventory,0)) + (self.h_r * self.returns_inventory) - (self.b * min(self.serviceable_inventory, 0)))*(t_event - self.clock)


        self.clock = t_event

        if t_event == self.t_demand:
            self.handle_demand_event()
        elif t_event == self.t_returns:
            self.handle_returns_event()
        elif t_event == self.t_remfgLeadTime[0]:
            self.handle_remfg_event()
        elif t_event == self.t_mfgLeadTime[0]:
            self.handle_mfg_event()

    #Demand Arrivals
    def handle_demand_event(self):
        self.serviceable_inventory -= 1.0
        self.inventory_position -= 1.0

        #Order if at cutoff
        if self.inventory_position == self.r_r:
            if self.returns_inventory >= self.Q_r:
                self.inventory_position += self.Q_r
                self.returns_inventory -= self.Q_r
                if self.t_remfgLeadTime[0] == float("inf"):
                    self.t_remfgLeadTime.pop(0)
                    self.t_remfgLeadTime.append(self.clock + self.L_r)
                else:
                    self.t_remfgLeadTime.append(self.clock + self.L_r)

                if self.clock >= self.TimeToSteadyState:
                    self.cost_orders_remfg += self.K_r + self.c_r * self.Q_r
                    self.cost_total += self.K_r + self.c_r * self.Q_r

        if self.inventory_position == self.r_p:
            self.inventory_position += self.Q_p
            if self.t_mfgLeadTime[0] == float("inf"):
                self.t_mfgLeadTime.pop(0)
                self.t_mfgLeadTime.append(self.clock + self.L_p)
            else:
                self.t_mfgLeadTime.append(self.clock + self.L_p)

            #update mfg ordering cost
            if self.clock >= self.TimeToSteadyState:
                self.cost_orders_mfg += self.K_p + self.c_p * self.Q_p
                self.cost_total += self.K_p + self.c_p * self.Q_p

        #update next demand arrival
        self.t_demand = self.clock + self.generate_interarrival_demand()

    #Return Arrivals
    def handle_returns_event(self):
        self.returns_inventory += 1

        #update next return
        self.t_returns = self.clock + self.generate_interarrival_returns()

    #Handle
    def handle_mfg_event(self):
        self.serviceable_inventory += self.Q_p
        if len(self.t_mfgLeadTime) == 1:
            self.t_mfgLeadTime.pop(0)
            self.t_mfgLeadTime.append(float("inf"))
        else:
            self.t_mfgLeadTime.pop(0)

    def handle_remfg_event(self):
        self.serviceable_inventory += self.Q_r
        if len(self.t_remfgLeadTime) == 1:
            self.t_remfgLeadTime.pop(0)
            self.t_remfgLeadTime.append(float("inf"))
        else:
            self.t_remfgLeadTime.pop(0)

    def generate_interarrival_demand(self):
        return np.random.exponential(1.0/self.demand_rate)#uses scale, not the lambda. so if Lambda = 5, we need to put 1/5

    def generate_interarrival_returns(self):
        return np.random.exponential(1.0/self.return_rate)


#note that  the assumption is that r_r >= r_p

def SimulateDoubleRQ(r_p, Q_p, r_r, Q_r, K_p, K_r, c_p, c_r, h_p, h_r, p, Lambda_d, Lambda_r, L_p, L_r, seed, TimeToSteadyState, TimeUnits):

    np.random.seed(seed)



    Trial = Simulation(r_p, Q_p, r_r, Q_r, K_p, K_r, c_p, c_r, h_p, h_r, p, Lambda_d, Lambda_r, L_p, L_r, TimeToSteadyState)
    IP = []
    SI = []
    RI = []
    Time = []
    counter = 0

    while Trial.clock <= TimeUnits:
        Trial.advance_time()

    return float(Trial.cost_total)/(float(Trial.clock) - float(TimeToSteadyState))#, float(Trial.cost_holding_returns)/(float(Trial.clock) - float(TimeToSteadyState)), float(Trial.cost_orders_remfg)/(float(Trial.clock) - float(TimeToSteadyState))
